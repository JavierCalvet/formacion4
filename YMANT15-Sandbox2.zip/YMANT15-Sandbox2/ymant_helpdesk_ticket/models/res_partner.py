# -*- coding: utf-8 -*-
from odoo import fields, models

class ResPartner(models.Model):
    _inherit = 'res.partner'

    external_url = fields.Char(string="External URL")
    company_notes = fields.Text(string="Company Notes")
    business_areas_id = fields.Many2one('res.business.areas', string="Business Area")
    technician_quality = fields.Selection(
        [('0', 'All'),
        ('1', 'Low'),
        ('2', 'Fair'),
        ('3', 'Good')],
        string='Technician Quality',
        help="Helps to define the level of the technician and its level of quality.")

    info = fields.Char(string='Info')
    teemip = fields.Char(string='Teemip')
    accesswork = fields.Char(string='Accesswork')
    required_document_ids = fields.One2many('res.document.type', 'contact_id', string='Required Documents',copy=True)

class BusinessAreas(models.Model):
    _description = 'Business Areas'
    _name = 'res.business.areas'

    name = fields.Char(string='Business Area', required=True, translate=True)
    helpdesk_team_id = fields.Many2one('helpdesk.team', string="Helpdesk Team", required=True)

class DocumentType(models.Model):
    _description = 'Document Types'
    _name = 'res.document.type'

    name = fields.Char(string='Name', required=True, translate=True)
    contact_id = fields.Many2one('res.partner', string='Contact')
    category = fields.Selection(
        [('empresa', 'Empresa'),
        ('autonómo', 'Autonómo'),
        ('trabajador', 'Trabajador')],
        string='Category'
    )
