# -*- coding: utf-8 -*-
from odoo import api, fields, models

class HelpdeskTicket(models.Model):
    _inherit = 'helpdesk.ticket'

    estimated_beginning_date = fields.Datetime(string='Estimated Beginning Date', default=lambda self: fields.Datetime.now())
    internal_notes = fields.Html()
    customer_contact_id = fields.Many2one('res.partner', string='Customer Contact')
    customer_contact_function = fields.Char(related='customer_contact_id.function', string='Customer Contact Job Position', readonly=True)
    customer_contact_email = fields.Char(related='customer_contact_id.email', string='Customer Contact Email', readonly=True)
    provider_id = fields.Many2one('res.partner', string='Provider')
    external_technician_id = fields.Many2one('res.partner', string='External Technician')
    manage_way = fields.Selection(
        [('remotely', 'Remotely'),
        ('onsite', 'Onsite'),
        ('workshop', 'Workshop')],
        string='Manage Way',
        help="Help to select on the ticket the way it is going to be Treated.")

    external_url = fields.Char(string="External URL", related='partner_id.external_url', readonly=True)
    company_notes = fields.Text(string="Company Notes", related='partner_id.company_notes')
    info = fields.Char(string='Info')
    teemip = fields.Char(string='Teemip')
    accesswork = fields.Char(string='Accesswork')
    technician_quality = fields.Selection(string='Technician Quality', related='provider_id.technician_quality', readonly=True)
    product_line_ids = fields.One2many(
        'helpdesk.ticket.product', 'ticket_id', string='Ticket Products Lines',
        copy=True)

    def action_mail_send(self):
        ''' Opens a wizard to compose an email, with relevant mail template '''
        self.ensure_one()
        ctx = {
            'default_model': 'helpdesk.ticket',
            'default_res_id': self.ids[0],
            'default_composition_mode': 'comment',
            'force_email': True,
            'without_followers': True,
        }
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': ctx,
        }

    @api.onchange('partner_id')
    def _onchange_product_id(self):
        for ticket in self:
            ticket.info = ticket.partner_id.info
            ticket.teemip = ticket.partner_id.teemip
            ticket.accesswork = ticket.partner_id.accesswork

    def _notify_compute_recipients(self, message, msg_vals):
        if self.env.context.get('without_followers'):
            return []
        return super()._notify_compute_recipients(message, msg_vals)

class HelpdeskTicketProduct(models.Model):
    _name = 'helpdesk.ticket.product'
    _description = 'Ticket Products'

    ticket_id = fields.Many2one('helpdesk.ticket', string='Ticket', ondelete='cascade', index=True)
    product_id = fields.Many2one('product.product', string='Product', required=False, readonly=False)
    quantity = fields.Float(string='Quantity', required=False, readonly=False, digits='Product Unit of Measure', default=1)
    uom_id = fields.Many2one(related='product_id.uom_id', required=False, readonly=True, string="Unit Of Measure")
    purchase_price = fields.Float(string='Purchase Price', required=False, readonly=False, digits='Product Price')
    price_unit = fields.Float(string='Sales Price', required=False, readonly=False, digits='Product Price')
    note = fields.Text(string="Notes", required=False, readonly=False)
    sequence = fields.Integer(string='Sequence', default=10)

    @api.onchange('product_id')
    def _onchange_product_id(self):
        for product in self:
            product.update({
                'purchase_price': product.product_id.standard_price,
                'price_unit': product.product_id.list_price
            })
