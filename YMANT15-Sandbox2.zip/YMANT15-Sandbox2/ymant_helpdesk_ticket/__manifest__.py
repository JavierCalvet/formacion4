# -*- coding: utf-8 -*-
{
    'name': "Ymant Servicios Helpdesk Ticket",

    'summary': """
        The helpdesk tickets should display some fields which will be processed by the assigned user.""",

    'description': """
        Task: 2711284
        This information is useful for ticket management.
    """,
    "author": "OdooPS",
    "website": "http://www.odoo.com",
    "category": "Custom Development",
    "version": "15.0.1.0.0",
    "license": "LGPL-3",
    'depends': [
        'account',
        'contacts',
        'helpdesk',
        'helpdesk_timesheet',
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/mail_template_data.xml',
        'data/business_areas_demo.xml',
        'wizard/mail_compose_message_views.xml',
        'views/res_partner_views.xml',
        'views/contact_views.xml',
        'views/helpdesk_views.xml',
    ],
}

