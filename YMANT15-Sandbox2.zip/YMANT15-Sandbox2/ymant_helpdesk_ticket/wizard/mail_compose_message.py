# -*- coding: utf-8 -*-
from odoo import _, api, fields, models, tools, Command

class MailComposer(models.TransientModel):
    _inherit = 'mail.compose.message'

    def action_send_mail(self):
        res = super().action_send_mail()
        if self.env.context.get('without_followers') and self.model == 'helpdesk.ticket':
            ticket_ids = self._context.get('active_ids')
            HelpdeskTicket = self.env['helpdesk.ticket']
            email_values = {
                'recipient_ids': self.partner_ids.ids,
                'attachment_ids': self.attachment_ids.ids,
                'attachments': [],
            }
            for ticket in HelpdeskTicket.browse(ticket_ids):
                self.template_id.send_mail(ticket.id, force_send=True, email_values=email_values)
        return res
