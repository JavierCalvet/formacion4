# -*- coding: utf-8 -*-
{
    'name': "Ymant Servicios CRM Sale",

    'summary': """
        This module will help to assign Business Area in CRM lead as well as in Sale Order.""",

    'description': """
        Task: 2711284
        This information is useful for management.
    """,
    "author": "OdooPS",
    "website": "http://www.odoo.com",
    "category": "Custom Development",
    "version": "15.0.1.0.0",
    "license": "LGPL-3",
    'depends': [
        'ymant_helpdesk_ticket',
        'account_accountant',
        'sale_margin',
        'sale_crm',
        'helpdesk_fsm',
        'purchase',
    ],
    'data': [
        'report/sale_report_templates.xml',
        'data/helpdesk_data.xml',
        'views/crm_lead_views.xml',
        'views/helpdesk_views.xml',
        'views/purchase_views.xml',
        'views/sale_views.xml',
        'views/account_move_views.xml',
    ],
}
