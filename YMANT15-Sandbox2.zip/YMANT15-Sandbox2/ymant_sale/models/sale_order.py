# -*- coding: utf-8 -*-
from odoo.exceptions import UserError
from odoo import api, fields, Command, models, _

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    business_areas_id = fields.Many2one('res.business.areas', string="Business Area")
    total_tickets = fields.Integer("Ticket Counts", compute="_compute_total_tickets", compute_sudo=True)
    ticket_id = fields.Many2one('helpdesk.ticket', 'Ticket', readonly=True)
    ticket_project_id = fields.Many2one('project.project', string='Ticket Project')

    @api.onchange('opportunity_id')
    def _onchange_opportunity_id(self):
        for opportunity in self:
            if opportunity.partner_id:
                opportunity.business_areas_id = opportunity.opportunity_id.business_areas_id.id

    def _compute_total_tickets(self):
        for record in self:
            record.total_tickets = self.env['helpdesk.ticket'].search_count([('ticket_sale_order_id', '=', record.id)])

    def action_ticket_view(self):
        action = self.env["ir.actions.actions"]._for_xml_id('helpdesk.helpdesk_ticket_action_main_tree')
        if self.total_tickets == 1:
            ticket = self.env['helpdesk.ticket'].search([('ticket_sale_order_id', '=', self.id)], limit = 1)
            action.update({
                'view_mode': 'form',
                'res_id': ticket.id,
                'views': [(False, 'form')],
            })
        action.update({
            'domain': [('ticket_sale_order_id', '=', self.id)],
            'context': {
                'default_partner_id': self.partner_id.id,
                'default_ticket_sale_order_id': self.id,
            }
        })
        return action

    def _prepare_invoice(self):
        # OVERRIDE this function for adding custom field named 'business_area_id'
        invoice_vals = super(SaleOrder, self)._prepare_invoice()
        if self.business_areas_id:
            invoice_vals.update({'business_areas_id': self.business_areas_id.id})
        return invoice_vals

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    note = fields.Text(string="Notes")

    @api.depends('price_subtotal', 'product_uom_qty', 'purchase_price')
    def _compute_margin(self):
        super()._compute_margin()
        # OVERRIDE this method to change 'margin_percent' calculation
        for line in self:
            # line.margin_percent = line.price_subtotal and line.margin/line.price_subtotal
            # custome code start:-
            # changed 'margin_percent' calculation based on 'purchase_price' rather than 'price_subtotal'
            line.margin_percent = line.purchase_price and (line.margin/(line.product_uom_qty or 1))/(line.purchase_price or 1)
            # custom code end

    @api.onchange('margin_percent')
    def _onchange_margin_percent(self):
        for line in self:
            ctx = self.env.context
            if line.purchase_price and ctx.get('is_margin_percent'):
                line.price_unit = line.purchase_price + (line.purchase_price * line.margin_percent)
