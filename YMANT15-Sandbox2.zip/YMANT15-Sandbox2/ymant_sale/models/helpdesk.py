# -*- coding: utf-8 -*-
from odoo import api, fields, models, Command, _
from odoo.exceptions import UserError

class HelpdeskTicket(models.Model):
    _inherit = 'helpdesk.ticket'

    ticket_sale_order_id = fields.Many2one('sale.order', string="Sales Order")
    ticket_purchase_order_id = fields.Many2one('purchase.order', string="Purchase Order")
    ticket_category_id = fields.Many2one('res.business.areas', string="Ticket Category")
    mark_as_done = fields.Boolean(string='Mark As Done')
    is_solved_stage = fields.Boolean(related='stage_id.is_solved')

    @api.onchange('ticket_sale_order_id')
    def _onchange_ticket_sale_order_id(self):
        for ticket in self:
            if ticket.ticket_sale_order_id:
                ticket.ticket_category_id = ticket.ticket_sale_order_id.business_areas_id.id

    @api.onchange('ticket_category_id')
    def _onchange_ticket_category_id(self):
        for ticket in self:
            if ticket.ticket_category_id:
                ticket.team_id = ticket.ticket_category_id.helpdesk_team_id.id

    def create_purchase_order(self):
        purchase_order = self.env['purchase.order'].create({
            'partner_id': self.provider_id.id,
            'project_id': self.project_id.id,
            'ticket_id': self.id,
            'order_line': [Command.create({
                'name': "[" + "T" + str(line.ticket_id.id) + "]" + ' ' + line.ticket_id.name,
                'product_id': line.product_id.id,
                'account_analytic_id': self.project_id.analytic_account_id.id,
                'note': line.note,
                'product_qty': line.quantity,
                'price_unit': line.purchase_price}
            ) for line in self.product_line_ids if line.purchase_price > 0 and line.quantity > 0],
        })
        return purchase_order

    def create_sales_order(self):
        sales_order = self.env['sale.order'].create({
            'partner_id': self.partner_id.id,
            'ticket_project_id': self.project_id.id,
            'ticket_id': self.id,
            'analytic_account_id': self.project_id.analytic_account_id.id,
            'order_line': [Command.create({
                'name': "[" + "T" + str(line.ticket_id.id) + "]" + ' ' + line.ticket_id.name,
                'product_id': line.product_id.id,
                'note': line.note,
                'product_uom_qty': line.quantity,
                'price_unit': line.price_unit}
            ) for line in self.product_line_ids if line.price_unit > 0 and line.quantity > 0],
        })
        return sales_order

    def action_mark_as_done(self):
        self.ensure_one()
        solved_stage = self.env.ref('helpdesk.stage_solved')
        '''  They have to put Team in the Solved Stage.
                If any Team is not in the Solved Stage,
                Raising User Error.'''
        if self.team_id.id in solved_stage.team_ids.ids:
            self.stage_id = solved_stage
        else:
            raise UserError(_("Kindly put '%s' Team in Solve Stage.", self.team_id.name))
        self.mark_as_done = True

    def create_so_po_solved_stage(self):
        for record in self:
            # checking so is created through current ticket or not
            is_so = self.env['sale.order'].search_count([('ticket_id', '=', record.id)])
            # checking po is created through current ticket or not
            is_po = self.env['purchase.order'].search_count([('ticket_id', '=', record.id)])
            '''  If PO is not created or created but deleted then we will create new PO from the current ticket
                While we put ticket into Solved Stage or making as a Mark As Done '''
            if not is_po:
                po = record.create_purchase_order()
                po.button_confirm()
                template = self.env.ref('purchase.email_template_edi_purchase_done')
                record.ticket_purchase_order_id = po.id
                if template:
                    template.send_mail(po.id) # sending email with attached PO to External Technician
            '''  If SO is not created or created but deleted then we will create new SO from the current ticket
                While we put ticket into Solved Stage or making as a Mark As Done '''
            if not is_so:
                so = record.create_sales_order()
                so.action_confirm()
                record.ticket_sale_order_id = so.id

    def write(self, vals):
        res = super(HelpdeskTicket, self).write(vals)
        if vals.get('stage_id'):
            solved_stage = self.env['helpdesk.stage'].browse(vals.get('stage_id')).is_solved
            if solved_stage and self.provider_id and self.product_line_ids:
                self.create_so_po_solved_stage()
        return res

class HelpdeskStage(models.Model):
    _inherit = 'helpdesk.stage'

    is_solved = fields.Boolean('Solved Stage', help='Tickets in this stage are considered as solved.')
