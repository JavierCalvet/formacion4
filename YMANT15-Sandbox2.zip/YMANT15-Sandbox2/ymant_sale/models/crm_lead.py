# -*- coding: utf-8 -*-
from odoo import api, fields, models

class Lead(models.Model):
    _inherit = 'crm.lead'

    business_areas_id = fields.Many2one('res.business.areas', string="Business Area")

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        for lead in self:
            if lead.partner_id:
                lead.business_areas_id = lead.partner_id.business_areas_id.id
