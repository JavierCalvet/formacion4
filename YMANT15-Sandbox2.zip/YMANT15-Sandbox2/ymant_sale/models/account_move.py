# -*- coding: utf-8 -*-
from odoo import api, fields, models

class AccountMove(models.Model):
    _inherit = "account.move"

    business_areas_id = fields.Many2one('res.business.areas', string="Business Area")
