# -*- coding: utf-8 -*-
from odoo import api, fields, models, _

class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    ticket_id = fields.Many2one('helpdesk.ticket', string='Ticket', readonly=True)
    project_id = fields.Many2one('project.project', string='Project')

class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'

    note = fields.Text(string="Notes")
